package com.example.qlbh_mypham.services.Impl;

import org.springframework.stereotype.Service;

@Service
public class KhachHangServiceImp {
}
