package com.example.qlbh_mypham;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QlbhMyPhamApplication {

	public static void main(String[] args) {
		SpringApplication.run(QlbhMyPhamApplication.class, args);
	}

}
