package com.example.qlbh_mypham;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QlbhMyPhamApplicationTests {

	@Test
	void contextLoads() {
	}

}
